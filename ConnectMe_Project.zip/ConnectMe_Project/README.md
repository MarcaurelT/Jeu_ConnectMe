# Connect_Me
Objectif du jeu : connecter toutes les broches des carrés entre eux



-> Pour que le jeu fonctionne votre environnement eclipse doit implémenter deux bibliothèques : slick2D et LGWL
un lien utile pour ma part : http://slick2d.wikidot.com/setting-up-slick2d-with-eclipse-ide
Enjoy
